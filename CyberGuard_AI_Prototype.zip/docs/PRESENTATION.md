# 8-slide pitch outline

## 1. Title
CyberGuard AI — Private security intelligence on your PC.

## 2. Problem
Phishing messages, suspicious URLs and risky attachments are everyday threats. Cloud scanning can also create privacy concerns.

## 3. Solution
A local desktop assistant that analyzes common threat signals and explains the result in plain language.

## 4. How it works
Input → local preprocessing → AI/rules → risk scoring → explanation.

## 5. Snapdragon advantage
The production architecture targets Snapdragon edge AI hardware so inference can happen locally, reducing network dependency and improving privacy.

## 6. Live demo
- Phishing message
- URL
- File
- Show result and explanation

## 7. Roadmap
Current prototype → Qualcomm AI Hub model → NPU benchmark → richer file/URL models → offline model updates.

## 8. Closing
CyberGuard AI turns on-device AI into a practical privacy-first security assistant.
