# Safe demo cases

## Case 1 — phishing
`URGENT! Your bank account will be locked today. Click here to verify your account and send the OTP immediately.`

Expected: HIGH RISK.

## Case 2 — normal
`Hi Naveen, the lab meeting is at 2 PM tomorrow. Please bring the project report.`

Expected: LOW RISK.

## Case 3 — URL
`http://example.com/login`

Expected: warning because it is not HTTPS.

Do not use real credentials, real OTPs, malware or personal documents in a public demonstration.
