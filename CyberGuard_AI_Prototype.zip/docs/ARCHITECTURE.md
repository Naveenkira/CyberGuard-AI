# Architecture

```text
                 ┌───────────────────────────┐
Message / URL ──►│  CyberGuard Desktop UI    │
File selection ─►│        (Electron)         │
                 └─────────────┬─────────────┘
                               │
                               ▼
                 ┌───────────────────────────┐
                 │ Local preprocessing       │
                 │ normalization / parsing   │
                 └─────────────┬─────────────┘
                               │
                  ┌────────────┴────────────┐
                  ▼                         ▼
        ┌───────────────────┐     ┌────────────────────┐
        │ Prototype rules   │     │ Production AI model│
        │ (current demo)    │     │ ONNX / AI Hub      │
        └─────────┬─────────┘     └──────────┬─────────┘
                  └────────────┬─────────────┘
                               ▼
                 ┌───────────────────────────┐
                 │ Explainable risk engine   │
                 │ score + findings + action │
                 └─────────────┬─────────────┘
                               ▼
                     User-friendly result
```

## Snapdragon optimization plan
- Prefer a compact quantized model suitable for edge inference.
- Convert/export to a supported ONNX representation where appropriate.
- Test Qualcomm AI Hub compilation for the exact Snapdragon platform.
- Use an appropriate local execution provider/runtime.
- Measure latency, memory and power against CPU fallback.
- Report real measured values only.
