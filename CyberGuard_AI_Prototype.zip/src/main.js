const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const { analyzeText, analyzeUrl, analyzeFile } = require("./security-engine");

function createWindow() {
  const win = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 1050,
    minHeight: 700,
    backgroundColor: "#07111f",
    title: "CyberGuard AI",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, "index.html"));
}

ipcMain.handle("analyze-text", (_, text) => analyzeText(text));
ipcMain.handle("analyze-url", (_, url) => analyzeUrl(url));

ipcMain.handle("choose-file", async () => {
  const result = await dialog.showOpenDialog({
    properties: ["openFile"],
    filters: [
      { name: "Common files", extensions: ["txt","pdf","doc","docx","jpg","png","zip","exe","msi","bat","cmd","ps1","js"] },
      { name: "All files", extensions: ["*"] }
    ]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  return analyzeFile(result.filePaths[0]);
});

ipcMain.handle("system-info", () => ({
  platform: process.platform,
  arch: process.arch,
  os: process.platform === "win32" ? "Windows" : process.platform,
  inferenceTarget: process.arch === "arm64" ? "ARM64 / Snapdragon-ready" : "Desktop compatibility mode",
  privacy: "Core analysis stays local"
}));

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});