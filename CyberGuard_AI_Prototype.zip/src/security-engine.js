const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

function result(score, findings, summary) {
  score = Math.max(0, Math.min(100, Math.round(score)));
  const level = score >= 70 ? "HIGH RISK" : score >= 35 ? "SUSPICIOUS" : "LOW RISK";
  return { score, level, findings, summary };
}

function add(findings, severity, title, detail, points) {
  findings.push({ severity, title, detail, points });
}

function analyzeText(text = "") {
  const findings = [];
  const t = String(text).trim();
  if (!t) return result(0, [{severity:"info", title:"No content", detail:"Paste an email, SMS, message or other text to analyze.", points:0}], "Waiting for content.");

  let score = 0;
  const rules = [
    [/urgent|immediately|act now|within \d+ hours/i, "Urgency language", "Pressure to act quickly is commonly used in social-engineering messages.", 16],
    [/otp|one[- ]time password|verification code/i, "OTP request", "Never disclose an OTP to a person or service that unexpectedly asks for it.", 25],
    [/password|passcode|login credential/i, "Credential request", "Requests for passwords or credentials are a strong warning sign.", 25],
    [/click here|verify your account|confirm your account|unlock your account/i, "Account-action lure", "The message asks the recipient to take a security-sensitive action.", 15],
    [/won|winner|prize|lottery|reward/i, "Prize lure", "Unexpected prizes/rewards are frequently used in phishing campaigns.", 15],
    [/gift card|crypto|bitcoin|wire transfer|bank transfer/i, "Payment red flag", "Unusual payment requests can indicate fraud or social engineering.", 25],
    [/bit\.ly|tinyurl\.com|t\.co\//i, "Shortened link", "Shortened links hide the final destination and deserve verification.", 12],
    [/free money|guaranteed profit|double your money/i, "Financial lure", "Guaranteed or unusually easy financial returns are a common scam signal.", 20]
  ];
  for (const [re, title, detail, points] of rules) {
    if (re.test(t)) { add(findings, points >= 25 ? "high" : "medium", title, detail, points); score += points; }
  }
  const urls = t.match(/https?:\/\/[^\s]+/gi) || [];
  if (urls.length > 0) {
    add(findings, "medium", "External URL detected", `${urls.length} URL(s) found. Check the domain before opening.`, 8);
    score += 8;
  }
  if ((t.match(/!/g) || []).length >= 4) {
    add(findings, "low", "High punctuation intensity", "Multiple exclamation marks can accompany pressure-based messaging.", 5);
    score += 5;
  }
  if (findings.length === 0) {
    add(findings, "info", "No strong rule-based indicators", "No major indicators in the prototype rule set were detected. This is not a guarantee of safety.", 0);
  }
  return result(score, findings, score >= 70 ? "Multiple strong social-engineering indicators detected." : score >= 35 ? "Some warning signs were detected. Verify independently." : "No major indicators were detected by the local prototype.");
}

function analyzeUrl(raw = "") {
  const findings = [];
  const url = String(raw).trim();
  if (!url) return result(0, [{severity:"info", title:"No URL", detail:"Enter a URL to inspect.", points:0}], "Waiting for a URL.");
  let u;
  try { u = new URL(url.includes("://") ? url : "https://" + url); }
  catch { return result(80, [{severity:"high", title:"Invalid URL", detail:"The input could not be parsed as a normal web URL.", points:80}], "Invalid URL format."); }

  let score = 0;
  const host = u.hostname.toLowerCase();
  if (u.protocol !== "https:") { add(findings,"high","No HTTPS","The URL does not use HTTPS.",25); score += 25; }
  if (host.includes("xn--")) { add(findings,"high","Punycode domain","Internationalized/punycode domains can be abused to create look-alike addresses.",30); score += 30; }
  if ((host.match(/\./g) || []).length >= 3) { add(findings,"medium","Deep subdomain","The domain contains multiple subdomain levels. Verify the actual registrable domain.",10); score += 10; }
  if (host.split("").filter(c => c === "-").length >= 3) { add(findings,"medium","Many hyphens","Unusually hyphenated domains deserve extra verification.",8); score += 8; }
  if (u.username || u.password) { add(findings,"high","Embedded credentials","The URL contains user-information before the host.",30); score += 30; }
  if (/[0-9]{5,}/.test(host)) { add(findings,"medium","Numeric-heavy host","A numeric-heavy host can be suspicious when unexpected.",12); score += 12; }
  if (/bit\.ly|tinyurl\.com|t\.co|goo\.gl/i.test(host)) { add(findings,"medium","URL shortener","Shortened URLs conceal the final destination.",15); score += 15; }
  if (findings.length === 0) add(findings,"info","No obvious URL red flags","The local prototype did not detect common structural warning signs.",0);
  return result(score, findings, score >= 70 ? "The URL has strong structural warning signs." : score >= 35 ? "Verify the domain and destination before proceeding." : "No major structural red flags were detected.");
}

function analyzeFile(filePath) {
  try {
    const stat = fs.statSync(filePath);
    const name = path.basename(filePath);
    const ext = path.extname(name).toLowerCase();
    const findings = [];
    let score = 0;
    const dangerous = [".exe",".msi",".scr",".bat",".cmd",".ps1",".vbs",".js",".jar",".hta"];
    if (dangerous.includes(ext)) {
      add(findings,"high","Executable/script type", `${ext} can execute code when opened or run.`, 40); score += 40;
    }
    if (stat.size > 100 * 1024 * 1024) {
      add(findings,"medium","Large file", "Large files should be verified when received unexpectedly.", 10); score += 10;
    }
    if ([".zip",".rar",".7z"].includes(ext)) {
      add(findings,"medium","Archive file", "Archives can contain hidden executables or scripts. Inspect contents before opening.", 15); score += 15;
    }
    const hash = crypto.createHash("sha256");
    const fd = fs.openSync(filePath, "r");
    const buffer = Buffer.alloc(Math.min(stat.size, 1024 * 1024));
    const bytes = fs.readSync(fd, buffer, 0, buffer.length, 0);
    fs.closeSync(fd);
    hash.update(buffer.subarray(0, bytes));
    if (!findings.length) add(findings,"info","No basic file red flags", "The prototype only performs lightweight local checks; it is not a malware scanner.", 0);
    return result(score, findings, `Local inspection complete. SHA-256 sample: ${hash.digest("hex")}.`);
  } catch (e) {
    return result(60, [{severity:"medium", title:"File could not be inspected", detail:e.message, points:60}], "Inspection failed.");
  }
}

module.exports = { analyzeText, analyzeUrl, analyzeFile };