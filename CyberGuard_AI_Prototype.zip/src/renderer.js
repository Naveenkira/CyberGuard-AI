const pages = document.querySelectorAll(".page");
const navs = document.querySelectorAll(".nav");
const title = document.getElementById("pageTitle");
const titles = {dashboard:"Security Dashboard",phishing:"Phishing Detector",url:"URL Inspector",files:"File Analyzer",about:"About CyberGuard"};

function showPage(id){
  pages.forEach(p=>p.classList.toggle("active",p.id===id));
  navs.forEach(n=>n.classList.toggle("active",n.dataset.page===id));
  title.textContent=titles[id] || "CyberGuard AI";
}
navs.forEach(n=>n.addEventListener("click",()=>showPage(n.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.goto)));

function renderResult(el, data){
  el.classList.remove("hidden");
  const cls=data.level==="HIGH RISK"?"high":data.level==="SUSPICIOUS"?"suspicious":"low";
  el.innerHTML = `
    <div class="risk ${cls}"><div><span class="eyebrow">LOCAL ASSESSMENT</span><h3>${data.level}</h3><p>${data.summary}</p></div><div class="score">${data.score}<small>/100</small></div></div>
    <div>${data.findings.map(f=>`<div class="finding"><b>${escapeHtml(f.title)}</b><small>${escapeHtml(f.detail)}</small></div>`).join("")}</div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

document.getElementById("analyzeText").onclick=async()=>{
  const text=document.getElementById("textInput").value;
  renderResult(document.getElementById("textResult"), await window.cyberguard.analyzeText(text));
};
document.getElementById("clearText").onclick=()=>{
  document.getElementById("textInput").value="";
  document.getElementById("textResult").classList.add("hidden");
};
document.getElementById("analyzeUrl").onclick=async()=>{
  renderResult(document.getElementById("urlResult"), await window.cyberguard.analyzeUrl(document.getElementById("urlInput").value));
};
document.getElementById("chooseFile").onclick=async()=>{
  const r=await window.cyberguard.chooseFile();
  if(r) renderResult(document.getElementById("fileResult"),r);
};
window.cyberguard.systemInfo().then(info=>{
  document.getElementById("arch").textContent=`${info.os} • ${info.arch} • ${info.inferenceTarget}`;
});