const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("cyberguard", {
  analyzeText: (text) => ipcRenderer.invoke("analyze-text", text),
  analyzeUrl: (url) => ipcRenderer.invoke("analyze-url", url),
  chooseFile: () => ipcRenderer.invoke("choose-file"),
  systemInfo: () => ipcRenderer.invoke("system-info")
});