# CyberGuard AI — Prototype

A privacy-first desktop cybersecurity assistant prototype for the Snapdragon AI Lab Build & Present Challenge.

## What is implemented
- Electron desktop UI for Windows
- Phishing/message detector
- URL structural inspector
- Local file risk inspector
- Explainable risk score (0–100)
- Privacy-first local processing
- Snapdragon/ARM64 readiness indicator
- Clear architecture and project documentation

## Run
1. Install Node.js LTS.
2. Open a terminal in this folder.
3. Run:
   `npm install`
4. Run:
   `npm start`

## Build Windows installer
`npm run dist`

## Important
This is a prototype, not an antivirus. The current security engine is deterministic and local. For a competition submission claiming AI/NPU inference, integrate a compatible model from Qualcomm AI Hub or another permitted open-source model and benchmark it on the target Snapdragon device. Do not claim NPU acceleration until it has been tested.

## Demo script
1. Open CyberGuard AI.
2. Paste a phishing message.
3. Show HIGH RISK score and explainable findings.
4. Inspect a suspicious URL without opening it.
5. Select a harmless test file.
6. Explain that the core prototype does not upload the content.
7. Show the Snapdragon/ARM64 readiness indicator.
8. Explain the production path: quantized ONNX model → Qualcomm AI Hub/ONNX Runtime execution provider → local inference → explainable UI.

## Suggested production AI layer
`Input → preprocessing → compact classifier/LLM → Snapdragon NPU execution → risk + explanation → UI`

Use only models/licensing allowed by the challenge rules and verify the target device/runtime before submission.
