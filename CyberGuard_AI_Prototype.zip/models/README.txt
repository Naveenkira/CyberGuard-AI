Place the permitted Qualcomm AI Hub/Open-source ONNX model here after selecting and testing it for the target Snapdragon platform.
The current prototype intentionally does not bundle a model or make unverified NPU-performance claims.
